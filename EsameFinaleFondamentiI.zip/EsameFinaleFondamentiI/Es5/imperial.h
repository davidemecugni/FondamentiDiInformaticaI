#define _CRT_SECURE_NO_WARNINGS
#if !defined IMPERIAL_H
#define IMPERIAL_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
extern double to_meter(const char* imperial_length);
#endif /*IMPERIAL_H*/