#include "imperial.h"

int main(void) {
	double res =  to_meter("26 miles 385 yards");
}